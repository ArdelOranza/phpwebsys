CREATE DATABASE IF NOT EXISTS usercourse_db;
USE usercourse_db;

CREATE TABLE user (
  user_ID int AUTO_INCREMENT PRIMARY KEY,
  firstname varchar(80),
  lastname varchar(80),
  middlename varchar(80),
  birthdate date,
  gender varchar(10),
  email varchar(160) UNIQUE,
  date_created datetime DEFAULT NOW()
);

CREATE TABLE course (
  course_ID int AUTO_INCREMENT PRIMARY KEY,
  name varchar(120),
  description text,
  course_code varchar(20) UNIQUE,
  status varchar(5) DEFAULT 'on',
  date_created datetime DEFAULT NOW()
);

CREATE TABLE user_course (
  user_ID int,
  course_ID int
);
