<?php
require 'config.php';
$action = $_GET['action'] ?? 'list';

if ($action=='add' && $_POST) {
    $em=$_POST['email'];
    if (mysqli_num_rows(mysqli_query($db,"SELECT user_ID FROM user WHERE email='$em'"))>0) $err="Email already exists!";
    else {
        mysqli_query($db,"INSERT INTO user (firstname,lastname,middlename,birthdate,gender,email) VALUES ('{$_POST['firstname']}','{$_POST['lastname']}','{$_POST['middlename']}','{$_POST['birthdate']}','{$_POST['gender']}','$em')");
        $uid=mysqli_insert_id($db);
        foreach($_POST['courses']??[] as $cid) mysqli_query($db,"INSERT INTO user_course VALUES ('$uid','$cid')");
        header("Location: index.php"); exit;
    }
}

if ($action=='edit' && $_POST) {
    $id=$_POST['id']; $em=$_POST['email'];
    if (mysqli_num_rows(mysqli_query($db,"SELECT user_ID FROM user WHERE email='$em' AND user_ID!='$id'"))>0) { $err="Email already used!"; $action='edit_form'; }
    else {
        mysqli_query($db,"UPDATE user SET firstname='{$_POST['firstname']}',lastname='{$_POST['lastname']}',middlename='{$_POST['middlename']}',birthdate='{$_POST['birthdate']}',gender='{$_POST['gender']}',email='$em' WHERE user_ID='$id'");
        mysqli_query($db,"DELETE FROM user_course WHERE user_ID='$id'");
        foreach($_POST['courses']??[] as $cid) mysqli_query($db,"INSERT INTO user_course VALUES ('$id','$cid')");
        header("Location: index.php"); exit;
    }
}

if ($action=='delete') {
    mysqli_query($db,"DELETE FROM user WHERE user_ID='{$_GET['id']}'");
    mysqli_query($db,"DELETE FROM user_course WHERE user_ID='{$_GET['id']}'");
    header("Location: index.php"); exit;
}

$all_courses = mysqli_query($db,"SELECT * FROM course ORDER BY name");

if ($action=='edit_form' || ($action=='edit' && isset($err))) {
    $eid=$_GET['id']??$_POST['id'];
    $eu=mysqli_fetch_assoc(mysqli_query($db,"SELECT * FROM user WHERE user_ID='$eid'"));
    if ($_POST) foreach(['firstname','lastname','middlename','birthdate','gender','email'] as $f) $eu[$f]=$_POST[$f];
    $ec=[]; $r=mysqli_query($db,"SELECT course_ID FROM user_course WHERE user_ID='$eid'");
    while($row=mysqli_fetch_assoc($r)) $ec[]=$row['course_ID'];
}

$w="WHERE 1=1";
if(!empty($_GET['keyword'])){$k=$_GET['keyword']; $w.=" AND (u.firstname LIKE '%$k%' OR u.lastname LIKE '%$k%' OR u.middlename LIKE '%$k%' OR c.description LIKE '%$k%' OR c.course_code LIKE '%$k%')";}
if(!empty($_GET['gender']))    $w.=" AND u.gender='{$_GET['gender']}'";
if(!empty($_GET['date_from'])) $w.=" AND DATE(u.date_created)>='{$_GET['date_from']}'";
if(!empty($_GET['date_to']))   $w.=" AND DATE(u.date_created)<='{$_GET['date_to']}'";

$res=mysqli_query($db,"SELECT u.*, GROUP_CONCAT(DISTINCT c.course_code SEPARATOR ', ') AS codes FROM user u LEFT JOIN user_course uc ON uc.user_ID=u.user_ID LEFT JOIN course c ON c.course_ID=uc.course_ID $w GROUP BY u.user_ID ORDER BY u.date_created DESC");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Users</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="wrap">

<?php if($action=='add' || ($action=='add' && isset($err))): ?>
<div class="box" style="max-width:680px;">
  <h5>Add User</h5>
  <?php if(isset($err)): ?><div class="alert-danger"><?=$err?></div><?php endif; ?>
  <form method="POST" action="index.php?action=add">
    <div class="row g-2 mb-3">
      <div class="col-md-4"><label class="form-label">First Name</label><input type="text" class="form-control form-control-sm" name="firstname" value="<?=$_POST['firstname']??''?>"></div>
      <div class="col-md-4"><label class="form-label">Last Name</label><input type="text" class="form-control form-control-sm" name="lastname" value="<?=$_POST['lastname']??''?>"></div>
      <div class="col-md-4"><label class="form-label">Middle Name</label><input type="text" class="form-control form-control-sm" name="middlename" value="<?=$_POST['middlename']??''?>"></div>
      <div class="col-md-4"><label class="form-label">Birthdate</label><input type="date" class="form-control form-control-sm" name="birthdate" value="<?=$_POST['birthdate']??''?>"></div>
      <div class="col-md-4"><label class="form-label">Gender</label>
        <select class="form-select form-select-sm" name="gender">
          <option value="">-- Select --</option>
          <option value="Male"   <?=(($_POST['gender']??'')=='Male')  ?'selected':''?>>Male</option>
          <option value="Female" <?=(($_POST['gender']??'')=='Female')?'selected':''?>>Female</option>
          <option value="Other"  <?=(($_POST['gender']??'')=='Other') ?'selected':''?>>Other</option>
        </select>
      </div>
      <div class="col-md-4"><label class="form-label">Email</label><input type="email" class="form-control form-control-sm" name="email" value="<?=$_POST['email']??''?>"></div>
      <div class="col-12"><label class="form-label">Courses</label>
        <div class="course-grid">
          <?php while($c=mysqli_fetch_assoc($all_courses)): ?>
          <label class="course-item"><input type="checkbox" name="courses[]" value="<?=$c['course_ID']?>"> <span><b><?=$c['course_code']?></b> – <?=$c['name']?> <?=$c['status']=='off'?'[off]':''?></span></label>
          <?php endwhile; ?>
        </div>
      </div>
    </div>
    <button type="submit" class="btn btn-dark btn-sm">Save</button>
    <a href="index.php" class="btn btn-secondary btn-sm">Cancel</a>
  </form>
</div>

<?php elseif($action=='edit_form' || ($action=='edit' && isset($err))): ?>
<div class="box" style="max-width:680px;">
  <h5>Edit User</h5>
  <?php if(isset($err)): ?><div class="alert-danger"><?=$err?></div><?php endif; ?>
  <form method="POST" action="index.php?action=edit">
    <input type="hidden" name="id" value="<?=$eu['user_ID']?>">
    <div class="row g-2 mb-3">
      <div class="col-md-4"><label class="form-label">First Name</label><input type="text" class="form-control form-control-sm" name="firstname" value="<?=$eu['firstname']?>"></div>
      <div class="col-md-4"><label class="form-label">Last Name</label><input type="text" class="form-control form-control-sm" name="lastname" value="<?=$eu['lastname']?>"></div>
      <div class="col-md-4"><label class="form-label">Middle Name</label><input type="text" class="form-control form-control-sm" name="middlename" value="<?=$eu['middlename']?>"></div>
      <div class="col-md-4"><label class="form-label">Birthdate</label><input type="date" class="form-control form-control-sm" name="birthdate" value="<?=$eu['birthdate']?>"></div>
      <div class="col-md-4"><label class="form-label">Gender</label>
        <select class="form-select form-select-sm" name="gender">
          <option value="">-- Select --</option>
          <option value="Male"   <?=$eu['gender']=='Male'  ?'selected':''?>>Male</option>
          <option value="Female" <?=$eu['gender']=='Female'?'selected':''?>>Female</option>
          <option value="Other"  <?=$eu['gender']=='Other' ?'selected':''?>>Other</option>
        </select>
      </div>
      <div class="col-md-4"><label class="form-label">Email</label><input type="email" class="form-control form-control-sm" name="email" value="<?=$eu['email']?>"></div>
      <div class="col-12"><label class="form-label">Courses</label>
        <div class="course-grid">
          <?php while($c=mysqli_fetch_assoc($all_courses)): ?>
          <label class="course-item"><input type="checkbox" name="courses[]" value="<?=$c['course_ID']?>" <?=in_array($c['course_ID'],$ec)?'checked':''?>> <span><b><?=$c['course_code']?></b> – <?=$c['name']?> <?=$c['status']=='off'?'[off]':''?></span></label>
          <?php endwhile; ?>
        </div>
      </div>
    </div>
    <button type="submit" class="btn btn-dark btn-sm">Update</button>
    <a href="index.php" class="btn btn-secondary btn-sm">Cancel</a>
  </form>
</div>

<?php else: ?>
<div class="box">
  <form method="GET" action="index.php" class="row g-2 align-items-end mb-3">
    <div class="col-auto"><input type="text" class="form-control form-control-sm" name="keyword" value="<?=$_GET['keyword']??''?>" placeholder="Search..."></div>
    <div class="col-auto">
      <select class="form-select form-select-sm" name="gender">
        <option value="">All Gender</option>
        <option value="Male"   <?=(($_GET['gender']??'')=='Male')  ?'selected':''?>>Male</option>
        <option value="Female" <?=(($_GET['gender']??'')=='Female')?'selected':''?>>Female</option>
        <option value="Other"  <?=(($_GET['gender']??'')=='Other') ?'selected':''?>>Other</option>
      </select>
    </div>
    <div class="col-auto"><input type="date" class="form-control form-control-sm" name="date_from" value="<?=$_GET['date_from']??''?>"></div>
    <div class="col-auto"><input type="date" class="form-control form-control-sm" name="date_to" value="<?=$_GET['date_to']??''?>"></div>
    <div class="col-auto"><button class="btn btn-dark btn-sm">Search</button> <a href="index.php" class="btn btn-secondary btn-sm">Clear</a></div>
    <div class="col-auto ms-auto"><a href="index.php?action=add" class="btn btn-dark btn-sm">+ Add User</a></div>
  </form>
  <table>
    <thead><tr><th>#</th><th>Lastname, Firstname</th><th>Middlename</th><th>Birthdate</th><th>Gender</th><th>Email</th><th>Courses</th><th>Date Registered</th><th>Action</th></tr></thead>
    <tbody>
    <?php $i=1; while($u=mysqli_fetch_assoc($res)): ?>
      <tr>
        <td><?=$i++?></td>
        <td><?=$u['lastname']?>, <?=$u['firstname']?></td>
        <td><?=$u['middlename']?:'-'?></td>
        <td><?=$u['birthdate']?date('M d, Y',strtotime($u['birthdate'])):'-'?></td>
        <td><?=$u['gender']?></td>
        <td><?=$u['email']?></td>
        <td><?=$u['codes']?:'-'?></td>
        <td><?=date('M d, Y',strtotime($u['date_created']))?></td>
        <td>
          <a href="index.php?action=edit_form&id=<?=$u['user_ID']?>" class="btn btn-warning btn-sm py-0">Edit</a>
          <a href="index.php?action=delete&id=<?=$u['user_ID']?>" class="btn btn-danger btn-sm py-0" onclick="return confirm('Delete?')">Delete</a>
        </td>
      </tr>
    <?php endwhile; ?>
    </tbody>
  </table>
</div>
<?php endif; ?>

</div>
</body>
</html>
