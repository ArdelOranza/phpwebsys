<?php
require 'config.php';
$action=$_GET['action']??'list';

if($action=='add' && $_POST){
    $cd=strtoupper($_POST['course_code']);
    if(mysqli_num_rows(mysqli_query($db,"SELECT course_ID FROM course WHERE course_code='$cd'"))>0) $err="Code already exists!";
    else { mysqli_query($db,"INSERT INTO course (name,description,course_code,status) VALUES ('{$_POST['name']}','{$_POST['description']}','$cd','{$_POST['status']}')"); header("Location: courses.php"); exit; }
}

if($action=='edit' && $_POST){
    $id=$_POST['id']; $cd=strtoupper($_POST['course_code']);
    if(mysqli_num_rows(mysqli_query($db,"SELECT course_ID FROM course WHERE course_code='$cd' AND course_ID!='$id'"))>0) { $err="Code already in use!"; $action='edit_form'; }
    else { mysqli_query($db,"UPDATE course SET name='{$_POST['name']}',description='{$_POST['description']}',course_code='$cd',status='{$_POST['status']}' WHERE course_ID='$id'"); header("Location: courses.php"); exit; }
}

if($action=='delete'){
    mysqli_query($db,"DELETE FROM course WHERE course_ID='{$_GET['id']}'");
    mysqli_query($db,"DELETE FROM user_course WHERE course_ID='{$_GET['id']}'");
    header("Location: courses.php"); exit;
}

if($action=='edit_form' || ($action=='edit' && isset($err))){
    $eid=$_GET['id']??$_POST['id'];
    $ec=mysqli_fetch_assoc(mysqli_query($db,"SELECT * FROM course WHERE course_ID='$eid'"));
    if($_POST) foreach(['name','description','course_code','status'] as $f) $ec[$f]=$_POST[$f];
}

$w="WHERE 1=1";
if(!empty($_GET['keyword'])){$k=$_GET['keyword']; $w.=" AND (name LIKE '%$k%' OR description LIKE '%$k%' OR course_code LIKE '%$k%')";}
if(!empty($_GET['status'])) $w.=" AND status='{$_GET['status']}'";

$res=mysqli_query($db,"SELECT c.*,(SELECT COUNT(*) FROM user_course uc WHERE uc.course_ID=c.course_ID) AS enrolled FROM course c $w ORDER BY date_created DESC");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Courses</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="wrap">

<?php if($action=='add'): ?>
<div class="box" style="max-width:580px;">
  <h5>Add Course</h5>
  <?php if(isset($err)): ?><div class="alert-danger"><?=$err?></div><?php endif; ?>
  <form method="POST" action="courses.php?action=add">
    <div class="row g-2 mb-3">
      <div class="col-12"><label class="form-label">Course Name</label><input type="text" class="form-control form-control-sm" name="name" value="<?=$_POST['name']??''?>"></div>
      <div class="col-md-6"><label class="form-label">Course Code</label><input type="text" class="form-control form-control-sm" name="course_code" value="<?=$_POST['course_code']??''?>" style="text-transform:uppercase"></div>
      <div class="col-md-6"><label class="form-label">Status</label>
        <select class="form-select form-select-sm" name="status">
          <option value="on"  <?=(($_POST['status']??'on')=='on') ?'selected':''?>>Active</option>
          <option value="off" <?=(($_POST['status']??'')=='off')  ?'selected':''?>>Inactive</option>
        </select>
      </div>
      <div class="col-12"><label class="form-label">Description</label><textarea class="form-control form-control-sm" name="description" rows="3"><?=$_POST['description']??''?></textarea></div>
    </div>
    <button type="submit" class="btn btn-dark btn-sm">Save</button>
    <a href="courses.php" class="btn btn-secondary btn-sm">Cancel</a>
  </form>
</div>

<?php elseif($action=='edit_form' || ($action=='edit' && isset($err))): ?>
<div class="box" style="max-width:580px;">
  <h5>Edit Course</h5>
  <?php if(isset($err)): ?><div class="alert-danger"><?=$err?></div><?php endif; ?>
  <form method="POST" action="courses.php?action=edit">
    <input type="hidden" name="id" value="<?=$ec['course_ID']?>">
    <div class="row g-2 mb-3">
      <div class="col-12"><label class="form-label">Course Name</label><input type="text" class="form-control form-control-sm" name="name" value="<?=$ec['name']?>"></div>
      <div class="col-md-6"><label class="form-label">Course Code</label><input type="text" class="form-control form-control-sm" name="course_code" value="<?=$ec['course_code']?>" style="text-transform:uppercase"></div>
      <div class="col-md-6"><label class="form-label">Status</label>
        <select class="form-select form-select-sm" name="status">
          <option value="on"  <?=$ec['status']=='on' ?'selected':''?>>Active</option>
          <option value="off" <?=$ec['status']=='off'?'selected':''?>>Inactive</option>
        </select>
      </div>
      <div class="col-12"><label class="form-label">Description</label><textarea class="form-control form-control-sm" name="description" rows="3"><?=$ec['description']?></textarea></div>
    </div>
    <button type="submit" class="btn btn-dark btn-sm">Update</button>
    <a href="courses.php" class="btn btn-secondary btn-sm">Cancel</a>
  </form>
</div>

<?php else: ?>
<div class="box">
  <form method="GET" action="courses.php" class="row g-2 align-items-end mb-3">
    <div class="col-auto"><input type="text" class="form-control form-control-sm" name="keyword" value="<?=$_GET['keyword']??''?>" placeholder="Search..."></div>
    <div class="col-auto">
      <select class="form-select form-select-sm" name="status">
        <option value="">All Status</option>
        <option value="on"  <?=(($_GET['status']??'')=='on') ?'selected':''?>>Active</option>
        <option value="off" <?=(($_GET['status']??'')=='off')?'selected':''?>>Inactive</option>
      </select>
    </div>
    <div class="col-auto"><button class="btn btn-dark btn-sm">Search</button> <a href="courses.php" class="btn btn-secondary btn-sm">Clear</a></div>
    <div class="col-auto ms-auto"><a href="courses.php?action=add" class="btn btn-dark btn-sm">+ Add Course</a></div>
  </form>
  <table>
    <thead><tr><th>#</th><th>Course Name</th><th>Code</th><th>Description</th><th>Status</th><th>Enrolled</th><th>Date Created</th><th>Action</th></tr></thead>
    <tbody>
    <?php $i=1; while($c=mysqli_fetch_assoc($res)): ?>
      <tr>
        <td><?=$i++?></td>
        <td><?=$c['name']?></td>
        <td><b><?=$c['course_code']?></b></td>
        <td><?=mb_strimwidth($c['description']??'-',0,60,'…')?></td>
        <td><span class="<?=$c['status']=='on'?'badge-on':'badge-off'?>"><?=$c['status']=='on'?'Active':'Inactive'?></span></td>
        <td><?=$c['enrolled']?></td>
        <td><?=date('M d, Y',strtotime($c['date_created']))?></td>
        <td>
          <a href="courses.php?action=edit_form&id=<?=$c['course_ID']?>" class="btn btn-warning btn-sm py-0">Edit</a>
          <a href="courses.php?action=delete&id=<?=$c['course_ID']?>" class="btn btn-danger btn-sm py-0" onclick="return confirm('Delete?')">Delete</a>
        </td>
      </tr>
    <?php endwhile; ?>
    </tbody>
  </table>
</div>
<?php endif; ?>

</div>
</body>
</html>
