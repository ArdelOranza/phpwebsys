<?php
$db = mysqli_connect('localhost', 'root', '', 'usercourse_db');
?>
